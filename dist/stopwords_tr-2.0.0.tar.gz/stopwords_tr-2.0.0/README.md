# STOPWORDS-TR

Stop words for Turkish.


## Installation / Kurulum

```bash
pip install stopwords_tr
```

## Usage / Kullan�m

```bash
>>> import stopwords_tr as stp
>>> stp.stopwords() #Stopwords Array List

```