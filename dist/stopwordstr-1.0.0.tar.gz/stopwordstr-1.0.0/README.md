<h1>STOPWORDS FOR TURKISH LANGUAGE</h1>
<h3>import stopwordstr</h3></h3>
<h3>stopwordstr.stopwords()</h3>